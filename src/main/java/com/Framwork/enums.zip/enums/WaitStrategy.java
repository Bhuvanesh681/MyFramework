package com.Framwork.enums;

public enum WaitStrategy {
	CLIKABLE,
	PRESENCE,
	VISIBLE,NONE;

}
