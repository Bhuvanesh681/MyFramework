package com.Framwork.enums;

/*
 * Category Type .can be used for grouping the test cases
 */
public enum CategoryType {
	REGRESSION,
	SMOKE,
	SANITY,
	MINIREGRESSION,

}
